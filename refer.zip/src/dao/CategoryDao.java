package dao;

import domain.Category;
import domain.User;
import test.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CategoryDao {

    private static Scanner sc = new Scanner(System.in);


    private Connection con = null;

    public CategoryDao() {
        try {
            con = DbUtil.getConnection();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    public boolean addCategory(Category y){

        String sql = "insert into categories values(default,?,?)";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setString(1,y.getTitle());
            stmt.setString(2,y.getDescription());
            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;



        }catch(Exception e) {
            e.printStackTrace();

        }
        return false;

    }

    public String getCategoryName(int catId){
        List<Category> tempList = showCategories();
        for(Category cat : tempList){
            if(cat.getId() == catId){
                return cat.getTitle();
            }
        }
        return null;
    }

    public List<Category> showCategories(){
        List<Category> catList = new ArrayList<Category>();
        String sql = "select * from categories";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            try(ResultSet rs = stmt.executeQuery()){
                while(rs.next()){
                    int id = rs.getInt("id");
                    String title = rs.getString("title");
                    String desc = rs.getString("description");
                    Category c = new Category(title,desc);
                    c.setId(id);
                    catList.add(c);
                }

            }
        }catch(Exception e) {
            e.printStackTrace();

        }
        return catList;
    }
    public void printCategories(){
        List<Category> displayList = showCategories();
        for(Category c : displayList){
            System.out.println(c.toString());
        }
    }
}
