package dao;

import domain.User;
import test.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class UserDao {

    private static Scanner sc = new Scanner(System.in);
    private static List<User> userList = new ArrayList<User>();

    private Connection con = null;



    public UserDao() {
        try {
            con = DbUtil.getConnection();
        }catch(Exception e) {
            e.printStackTrace();
        }

    }

    public boolean createUser(User u) {


        String sql = "INSERT INTO user values(default,?,?,?,?,?,default)";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setString(1,u.getFullName());
            stmt.setString(2,u.getEmail() );
            stmt.setString(3, u.getPassword());
            stmt.setString(4, u.getPhoneNo());
            stmt.setString(5, u.getAddress());
            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;



        }catch(Exception e) {
            e.printStackTrace();

        }
        return false;

    }

    public void displayOneUser(User u){

        String sql = "select * from user where email = ?";

        try(PreparedStatement stmt = con.prepareStatement(sql)){
          stmt.setString(1, u.getEmail());

            try(ResultSet rs = stmt.executeQuery()){
                if(rs.next()) {
                    int id = rs.getInt("id");
                    String fname = rs.getString("full_name");
                    String email = rs.getString("email");
                    String password = rs.getString("password");
                    String mobile = rs.getString("phone_no");
                    String address = rs.getString("address");
                    Date date = rs.getTimestamp("created_time");
                    User oneUser = new User(fname,email,password,mobile,address,date);
                    oneUser.setId(id);
                    System.out.println(oneUser.toString());
                }
            }

        }catch(Exception e) {
            e.printStackTrace();
        }

    }


    public User getCurrentUser(String em,String pass) {
        String sql = "select * from user where email = ? and password = ?";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setString(1, em);
            stmt.setString(2, pass);
            try(ResultSet rs = stmt.executeQuery()){
                if(rs.next()) {
                    int id = rs.getInt("id");
                    String fname = rs.getString("full_name");
                    String email = rs.getString("email");
                    String password = rs.getString("password");
                    String mobile = rs.getString("phone_no");
                    String address = rs.getString("address");
                    Date date = rs.getTimestamp("created_time");
                    User u = new User(fname,email,password,mobile,address,date);
                    u.setId(id);
                    return u;
                }
            }

        }catch(Exception e) {
            e.printStackTrace();
        }

        return null;

    }

    public List<User> getAllUsers() {
        List<User> allUsers = new ArrayList<>();
        String sql = "select * from user";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            try(ResultSet rs = stmt.executeQuery()){
                while(rs.next()) {
                    int id = rs.getInt("id");
                    String fname = rs.getString("full_name");
                    String email = rs.getString("email");
                    String password = rs.getString("password");
                    String mobile = rs.getString("phone_no");
                    String address = rs.getString("address");
                    Date date = rs.getTimestamp("created_time");
                    User a = new User(fname,email,password,mobile,address,date);
                    a.setId(id);
                    allUsers.add(a);
                }
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
        return allUsers;
    }

    public String getUserNameByUserId(int userId) {
        for(User u : getAllUsers()) {
            if(u.getId() == userId) {
                return u.getFullName();
            }
        }
        return null;
    }
}
