package dao;

import domain.Blog;
import domain.Category;
import test.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class BlogDao {
    private static Scanner sc = new Scanner(System.in);
    private static List<Blog> blogList = new ArrayList<Blog>();
    private Connection con = null;
    public BlogDao() {
        try {
            con = DbUtil.getConnection();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }


    public List<Blog> displayBlogs(){
        List<Blog> bList = new ArrayList<Blog>();
        String sql = "select * from blogs";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            try(ResultSet rs = stmt.executeQuery()){
                while(rs.next()){
                    int id = rs.getInt("id");
                    String title = rs.getString("title");
                    String contents = rs.getString("contents");
                    Date date = rs.getTimestamp("created_time");
                    int uid = rs.getInt("user_id");
                    int cid = rs.getInt("category_id");
                    Blog b = new Blog(title,contents,uid,cid);
                    b.setDate(date);
                    b.setId(id);
                    bList.add(b);
                }


            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return bList;

//        for(Blog b : bList){
//            System.out.println(b);
//        }
    }

    public void printAllBlogs(){
        List<Blog> allBlogs = displayBlogs();
        for(Blog blog : allBlogs){
//            String categoryTitle = new CategoryDao().getCategoryName(blog.getCategoryId());
//            System.out.println(blog.getId()+ "     "+blog.getTitle()+"     "+categoryTitle+ "     "+blog.getContents()+ blog.getUserId()+"     ["+blog.getDate()+"]");
            System.out.println(blog);
        }
    }


    public boolean createBlog(int catId,int userId,Blog b){

        String sql = "insert into blogs values(default,?,?,default,?,?)";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setString(1,b.getTitle());
            stmt.setString(2,b.getContents());
            stmt.setInt(3,userId);
            stmt.setInt(4,catId);
            int count = stmt.executeUpdate();
            return count > 0;

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public List<Blog>showMyBlogs(int id){

        List<Blog> bList = new ArrayList<Blog>();
        String sql = "select * from blogs where user_id = ?";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setInt(1,id);
            try(ResultSet rs = stmt.executeQuery()){
                while (rs.next()) {
                    int nid = rs.getInt("id");
                    String title = rs.getString("title");
                    String contents = rs.getString("contents");
                    Date date = rs.getTimestamp("created_time");
                    int uid = rs.getInt("user_id");
                    int cid = rs.getInt("category_id");
                    Blog b = new Blog(title, contents, uid, cid);
                    b.setId(nid);
                    b.setDate(date);
                    bList.add(b);
                }
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return bList;
    }


    public void printMyBlogs(int id){
        List<Blog> myBlogs = showMyBlogs(id);
        for(Blog blog : myBlogs){
//            String categoryTitle = new CategoryDao().getCategoryName(blog.getCategoryId());
//            System.out.println(blog.getId()+ "     "+blog.getTitle()+"     "+categoryTitle+ "     "+blog.getContents()+ blog.getUserId()+"     ["+blog.getDate()+"]");
            System.out.println(blog);
        }
    }

    public boolean deleteBlog(int blogId , int userId){

        String sql = "delete from blogs where user_id = ? and id = ?";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setInt(1,userId);
            stmt.setInt(2,blogId);
            int count = stmt.executeUpdate();
            return count > 0;

        }catch (Exception e){
            e.printStackTrace();
        }

        return false;

    }

    public void readBlogContent(int id){
        String sql = "select title , contents from blogs where id = ?";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setInt(1,id);
            try(ResultSet rs = stmt.executeQuery()){
                while (rs.next()){
                    String title = rs.getString("title");
                    String contents = rs.getString("contents");

                    System.out.println("Blog Contents are as follows : ");
                    System.out.println("-----------------------------------------");
                    System.out.println("Blog Name : "+ title);
                    System.out.println(contents);
                    System.out.println("-----------------------------------------");
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public boolean editBlog(int blogID,String contents, int userId){
        String sql = "update blogs set contents = ? where id = ? AND user_id = ?";
        try(PreparedStatement stmt = con.prepareStatement(sql)){
            stmt.setString(1,contents);
            stmt.setInt(2,blogID);
            stmt.setInt(3, userId);

            int count = stmt.executeUpdate();

            return count > 0;

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;

    }

    public void searchContentOfBlogs(String word) {
        boolean flag = false;
        List<Blog> blogs = displayBlogs();
        for (Blog blog : blogs) {
            if (blog.getContents().toLowerCase().contains(word.toLowerCase())) {
                System.out.println("blog id: " + blog.getId() + " - " + blog.getTitle());
                flag = true;
            }
        }
        if (!flag) {
            System.out.println("No blog found for given word " + word);
        }
    }

}
