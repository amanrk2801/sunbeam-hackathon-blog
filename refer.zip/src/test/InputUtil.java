package test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class InputUtil {

    private static Scanner sc = new Scanner(System.in);

    public static String readString() {
        return sc.nextLine().trim();
    }

    public static int readInt() {
        while (true) {
            try {
                return Integer.valueOf(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid number! Please try again.");
            }
        }
    }
}
