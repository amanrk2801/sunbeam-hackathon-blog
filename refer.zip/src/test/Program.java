package test;

import dao.BlogDao;
import dao.CategoryDao;
import dao.UserDao;
import domain.Blog;
import domain.Category;
import domain.User;

import java.util.List;
import java.util.Scanner;
public class Program {

    public static User currentUser = null;
    private static Scanner sc  = new Scanner(System.in);
    private static UserDao userDao = new UserDao();
    private static CategoryDao categoryDao = new CategoryDao();
    private static BlogDao blogDao = new BlogDao();

    public static void mainMenu(Scanner sc) {
        while (true) {
            System.out.println();
            System.out.println("****************Blog Management System******************");
            System.out.println();
            if (currentUser == null) {
                System.out.println("1. Sign In");
                System.out.println("2. Sign Up");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {
                    case 1:
                        signIn();
                        break;
                    case 2:
                        signUp();
                        break;
                    case 0:
                        System.out.println("Goodbye!");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice");
                }
            } else {

                System.out.println("1. Show Category");
                System.out.println("2. Add Category");
                System.out.println("3. Create Blog");
                System.out.println("4. Display All Blogs");
                System.out.println("5. Show My Blogs");
                System.out.println("6. Delete Blogs");
                System.out.println("7. Read Blog Contents");
                System.out.println("8. Edit Blog");
                System.out.println("9. Search Blog");
                System.out.println("0. Logout");
                System.out.println();
                System.out.println("[You are login as : " + currentUser.getFullName()+ "]");


//                int choice = sc.nextInt();
//                sc.nextLine();
                int choice = Integer.valueOf(sc.nextLine());

                switch (choice) {

                    case 1:
                        displayCategories();
                        break;
                    case 2:

                        addCategory();
                        break;
                    case 3:
                        addBlog();
                        break;
                    case 4:
                        blogDao.printAllBlogs();
//                        blogDao.displayBlogs();
                        break;
                    case 5:
                        blogDao.printMyBlogs(currentUser.getId());
                        break;
                    case 6:
                        deleteBlog();
                        break;
                    case 7:
                        showBlogContent();
                        break;
                    case 8:
                        editBlogContent();
                        break;
                    case 9:
                        searchForBlogContent();
                        break;
                    case 0:
                        currentUser = null;
                        System.out.println("Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice");
                }
            }
        }
    }


    public static void signUp(){
        String fullName;
        String email;
        String password;
        String phone;
        String address;

        System.out.println("Enter your name: ");
        fullName = sc.nextLine();
        System.out.println("Enter your email: ");
//        email = sc.nextLine();
//        email;
        while(true){
            List<User> allUsers = userDao.getAllUsers();
            boolean doesExist = false;
            email = sc.nextLine();
            for(User user : allUsers){
                if(user.getEmail().equals(email)){
                    doesExist = true;
                    break;
                }
            }
            if(doesExist == true){
                System.out.println("email already exists");
            }else{
                 break;
            }
        }
        System.out.println("Enter your password: ");
        password = sc.nextLine();
        System.out.println("Enter your phone: ");
        phone = sc.nextLine();
        System.out.println("Enter your address: ");
        address = sc.nextLine();
        User user = new User();
        user.setFullName(fullName);;
        user.setEmail(email);
        user.setPassword(password);
        user.setPhoneNo(phone);
        user.setAddress(address);
        userDao.createUser(user);
        userDao.displayOneUser(user);
    }



    private static void signIn(){
        try{
            System.out.println("Enter email");
            String email = sc.nextLine();
            System.out.println("Enter password");
            String password = sc.nextLine();
            currentUser = userDao.getCurrentUser(email, password);

            if(currentUser == null){
                System.out.println("Invalid email or password");
            }
        }catch (Exception e){
            System.out.println("Invalid email or password "+e.getMessage());
        }
    }

    private static void addCategory(){
        System.out.println("Enter Title :");
        String title = sc.nextLine();
        System.out.println("Enter Description :");
        String description = sc.nextLine();
        Category category = new Category(title, description);
        categoryDao.addCategory(category);
    }

    private static void displayCategories(){
        categoryDao.printCategories();
    }

    private static void addBlog(){
        System.out.println("Enter Blog Title :");
        String title = sc.nextLine();
        System.out.println("Select Category :");
        System.out.println();
        categoryDao.printCategories();
        System.out.println();

        System.out.println("Enter Category Id:");
        int categoryId;
        while(true){
            categoryId = Integer.valueOf(sc.nextLine());
            boolean result = validateCategory(categoryId);
            if(result){
                break;
            }else{
                System.out.println("Invalid Category Id, please try again");
            }
        }
        System.out.println("Enter Content of Blog: ");
        String content = sc.nextLine();

        Blog blog = new Blog(title, content, currentUser.getId() ,categoryId);
        boolean result = blogDao.createBlog(categoryId, currentUser.getId(), blog);
        if(result){
            System.out.println("Blog created successfully");
        }else{
            System.out.println("Blog could not be created");
        }
    }

    public static boolean validateCategory(int categoryId){
        List<Category> temp = categoryDao.showCategories();
        for(Category category : temp){
            if(categoryId == category.getId()){
                return true;
            }
        }
        return false;
    }

    public static void deleteBlog(){
        blogDao.printMyBlogs(currentUser.getId());
        System.out.println("Enter Blog id to delete :");
        int blogId;
        while(true){
            blogId = Integer.valueOf(sc.nextLine());
            boolean result = validateBlog(blogId);
            if(result){
                break;
            }else{
                System.out.println("Invalid Blog Id, please try again");
            }
        }

        boolean result = blogDao.deleteBlog(blogId, currentUser.getId());
        if(result){
            System.out.println("Blog deleted successfully");
        }
        else{
            System.out.println("You are not authorized user");
        }
    }

    public static boolean validateBlog(int blogId){
        List<Blog> temp = blogDao.displayBlogs();
        for(Blog blog : temp){
            if(blogId == blog.getId()){
                return true;
            }
        }
        return false;
    }

    public static void showBlogContent(){
        blogDao.printAllBlogs();
        System.out.println("Enter Blog id to read the content: ");
        int blogId;
        while(true){
            blogId = Integer.valueOf(sc.nextLine());
            boolean result = validateBlog(blogId);
            if(result){
                break;
            }else{
                System.out.println("Invalid Blog Id, please try again");
            }
        }
        blogDao.readBlogContent(blogId);
    }

    public static boolean validateMyBlogsId(int blogId){
        List<Blog> temp = blogDao.showMyBlogs(currentUser.getId());
        for(Blog blog : temp){
            if(blogId == blog.getId()){
                return true;
            }
        }
        return false;
    }


    public static void editBlogContent(){
        blogDao.printMyBlogs(currentUser.getId());
        System.out.println("Enter Blog id to update the content: ");
        int blogId;
        while(true){
            blogId = Integer.valueOf(sc.nextLine());
            boolean result = validateBlog(blogId);
            if(result){
                break;

            }else{
                System.out.println("Invalid Blog Id, please try again");
            }
        }
        boolean result = validateMyBlogsId(blogId);
        if(!result){
//            System.out.println("Blog deleted successfully");
            System.out.println("You are not authorized user");

        }
        else{
            System.out.println("Enter the new content: ");
            String newContent = sc.nextLine();
            blogDao.editBlog(blogId, newContent, currentUser.getId());
            return;
        }

    }

    public static void searchForBlogContent(){
        System.out.println("Enter the word to search for particular blog: ");
        String word = sc.nextLine();
        blogDao.searchContentOfBlogs(word);
    }

    public static void main(String[] args) {
        mainMenu(sc);
    }
}

