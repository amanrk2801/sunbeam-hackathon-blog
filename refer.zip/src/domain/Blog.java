package domain;

import dao.CategoryDao;
import dao.UserDao;

import java.util.Date;

public class Blog {

    private int id;
    private String title;
    private String contents;
    private Date date;
    private int userId;
//    private Category category;
    private int categoryId;

    public Blog() {
    }

    public Blog(String title, String contents, int userId, int categoryId) {
        this.title = title;
        this.contents = contents;
//        this.date = date;
        this.userId = userId;
        this.categoryId = categoryId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryNameById(int categoryId) {
        CategoryDao categoryDao = new CategoryDao();
        return categoryDao.getCategoryName(categoryId);
    }
    public String getUserNameById(int userId) {
        UserDao userDao = new UserDao();
        return userDao.getUserNameByUserId(userId);
    }

    @Override
    public String toString() {
        return "Blog{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", contents='" + contents + '\'' +
                ", date=" + date +
                ", userId=" +userId+ "-"+getUserNameById(userId)+
                ", category Name=" + getCategoryNameById(categoryId) +
                '}';
//        return String.format("%-10d %-10s %-10s %-10s %-10s %-10s", id, title, contents, date, userId, categoryId);
    }
}
